# NOBLE AUCTION — screen and data design

## Screen map

### Public
- `/` Marketplace home, search, category filter, active auctions
- `/auctions/[id]` Auction detail, image gallery, current price, bid history, bid action, seller profile, report action (next implementation)
- `/categories/[slug]` Category listing (next implementation)
- `/login` Email sign-in / registration
- `/terms`, `/privacy`, `/fees`, `/prohibited-items` Legal pages (must be reviewed before public launch)

### Member
- `/account` Profile and identity verification status (next implementation)
- `/sell/new` Listing form and image upload (next implementation)
- `/account/listings` Seller's listings (next implementation)
- `/account/bids` Bid history and watchlist (next implementation)
- `/orders/[id]` Payment, shipping, receipt, review (next implementation)

### Operator
- `/admin` Moderation dashboard (next implementation; server-side role authorization required)
- Review pending listings, suspend users, review reports, inspect orders, export fee ledger, audit actions.

## Database relationships

- `auth.users` 1:1 `profiles`
- `profiles` 1:N `auctions` (seller)
- `categories` 1:N `auctions`
- `auctions` 1:N `auction_images`
- `auctions` 1:N `bids`; each bid belongs to one bidder profile
- `profiles` N:M `auctions` through `watchlists`
- `auctions` 1:0..1 `orders`
- `orders` 1:N `payments`
- `profiles` 1:0..1 `seller_accounts`
- `orders` 1:N `reviews` (one review per party)
- `profiles` 1:N `reports`

## Business decisions currently assumed

- General marketplace; used and new goods only where lawful and provider-approved.
- Platform commission is 5% of winning price, stored as a rate snapshot on each auction.
- Seller listings start in `pending_review`; an operator must approve them before they become public.
- Anti-sniping extension: a bid within the final five minutes moves the end time to five minutes after the accepted bid.
- Minimum bid increments are provisional: JPY 500 / 1,000 / 5,000 by price band.
- No real payment or seller payout is enabled in this starter.
