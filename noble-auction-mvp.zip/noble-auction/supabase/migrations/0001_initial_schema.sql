-- NOBLE AUCTION initial schema (Supabase / PostgreSQL)
-- Apply in a new Supabase project using the SQL Editor or Supabase CLI.

create extension if not exists pgcrypto;

create type public.auction_status as enum ('draft','pending_review','active','ended','cancelled','removed');
create type public.order_status as enum ('awaiting_payment','paid','shipped','delivered','completed','cancelled','disputed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 40),
  phone_verified_at timestamptz,
  identity_status text not null default 'unverified' check (identity_status in ('unverified','pending','verified','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  sort_order int not null default 0,
  is_active boolean not null default true
);

create table public.auctions (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  category_id uuid references public.categories(id),
  title text not null check (char_length(title) between 3 and 100),
  description text not null default '' check (char_length(description) <= 10000),
  start_price bigint not null check (start_price > 0),
  current_price bigint not null check (current_price > 0),
  buy_now_price bigint check (buy_now_price is null or buy_now_price >= start_price),
  reserve_price bigint check (reserve_price is null or reserve_price >= start_price),
  status public.auction_status not null default 'pending_review',
  starts_at timestamptz not null default now(),
  ends_at timestamptz not null,
  original_ends_at timestamptz not null,
  extension_count int not null default 0,
  bid_count int not null default 0,
  highest_bidder_id uuid references public.profiles(id),
  platform_fee_rate numeric(5,4) not null default 0.0500 check (platform_fee_rate >= 0 and platform_fee_rate <= 0.2000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create table public.auction_images (
  id uuid primary key default gen_random_uuid(),
  auction_id uuid not null references public.auctions(id) on delete cascade,
  storage_path text not null,
  public_url text not null,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table public.bids (
  id uuid primary key default gen_random_uuid(),
  auction_id uuid not null references public.auctions(id) on delete cascade,
  bidder_id uuid not null references public.profiles(id),
  amount bigint not null check (amount > 0),
  created_at timestamptz not null default now(),
  unique (auction_id, bidder_id, amount)
);
create index bids_auction_created_idx on public.bids(auction_id, created_at desc);

create table public.watchlists (
  user_id uuid not null references public.profiles(id) on delete cascade,
  auction_id uuid not null references public.auctions(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, auction_id)
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  auction_id uuid not null unique references public.auctions(id),
  seller_id uuid not null references public.profiles(id),
  buyer_id uuid not null references public.profiles(id),
  winning_bid_id uuid references public.bids(id),
  winning_amount bigint not null check (winning_amount > 0),
  platform_fee_rate numeric(5,4) not null check (platform_fee_rate >= 0 and platform_fee_rate <= 0.2000),
  platform_fee_amount bigint not null check (platform_fee_amount >= 0),
  seller_receivable_amount bigint not null check (seller_receivable_amount >= 0),
  status public.order_status not null default 'awaiting_payment',
  payment_due_at timestamptz,
  paid_at timestamptz,
  shipped_at timestamptz,
  delivered_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  provider text not null,
  provider_payment_id text unique,
  amount bigint not null check (amount > 0),
  currency text not null default 'jpy',
  status text not null default 'pending',
  provider_fee_amount bigint,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.seller_accounts (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  provider text not null,
  provider_account_id text not null unique,
  onboarding_complete boolean not null default false,
  payouts_enabled boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  reviewer_id uuid not null references public.profiles(id),
  reviewee_id uuid not null references public.profiles(id),
  rating int not null check (rating between 1 and 5),
  comment text not null default '' check (char_length(comment) <= 1000),
  created_at timestamptz not null default now(),
  unique (order_id, reviewer_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id),
  auction_id uuid references public.auctions(id),
  reason text not null,
  details text not null default '' check (char_length(details) <= 2000),
  status text not null default 'open' check (status in ('open','investigating','resolved','rejected')),
  created_at timestamptz not null default now()
);

-- Create a profile row after a user signs up. display_name can be edited later.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data->>'display_name',''), nullif(split_part(coalesce(new.email,''),'@',1),''), 'member'));
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Bidding is serialized by locking the auction row. Minimum increment: JPY 500 up to 9,999;
-- JPY 1,000 from 10,000; JPY 5,000 from 100,000. Review these commercial rules before launch.
create or replace function public.place_bid(p_auction_id uuid, p_amount bigint)
returns jsonb language plpgsql security definer set search_path = public, auth as $$
declare
  v_user uuid := auth.uid();
  v_auction public.auctions%rowtype;
  v_increment bigint;
  v_new_end timestamptz;
begin
  if v_user is null then raise exception 'ログインしてください。'; end if;
  select * into v_auction from public.auctions where id = p_auction_id for update;
  if not found then raise exception '商品が見つかりません。'; end if;
  if v_auction.status <> 'active' then raise exception 'このオークションは入札できません。'; end if;
  if v_auction.seller_id = v_user then raise exception '自分の商品には入札できません。'; end if;
  if now() < v_auction.starts_at or now() >= v_auction.ends_at then raise exception '入札受付期間外です。'; end if;
  v_increment := case when v_auction.current_price < 10000 then 500 when v_auction.current_price < 100000 then 1000 else 5000 end;
  if p_amount < v_auction.current_price + v_increment then raise exception '最低入札額は % 円です。', v_auction.current_price + v_increment; end if;
  insert into public.bids (auction_id, bidder_id, amount) values (p_auction_id, v_user, p_amount);
  v_new_end := v_auction.ends_at;
  if v_auction.ends_at - now() <= interval '5 minutes' then
    v_new_end := now() + interval '5 minutes';
  end if;
  update public.auctions set current_price = p_amount, highest_bidder_id = v_user,
    bid_count = bid_count + 1, ends_at = v_new_end,
    extension_count = extension_count + case when v_new_end > v_auction.ends_at then 1 else 0 end,
    updated_at = now()
  where id = p_auction_id;
  return jsonb_build_object('current_price', p_amount, 'ends_at', v_new_end, 'bid_count', v_auction.bid_count + 1);
end;
$$;
revoke all on function public.place_bid(uuid,bigint) from public;
grant execute on function public.place_bid(uuid,bigint) to authenticated;

-- Finalize expired auctions. Call from a trusted scheduled job (not from the browser).
create or replace function public.finalize_expired_auctions()
returns integer language plpgsql security definer set search_path = public as $$
declare r record; v_fee bigint; v_count integer := 0;
begin
  for r in select * from public.auctions where status = 'active' and ends_at <= now() for update skip locked loop
    update public.auctions set status = 'ended', updated_at = now() where id = r.id;
    if r.highest_bidder_id is not null and (r.reserve_price is null or r.current_price >= r.reserve_price) then
      v_fee := floor(r.current_price * r.platform_fee_rate)::bigint;
      insert into public.orders (auction_id,seller_id,buyer_id,winning_amount,platform_fee_rate,platform_fee_amount,seller_receivable_amount,status,payment_due_at)
      values (r.id,r.seller_id,r.highest_bidder_id,r.current_price,r.platform_fee_rate,v_fee,r.current_price-v_fee,'awaiting_payment',now()+interval '48 hours')
      on conflict (auction_id) do nothing;
    end if;
    v_count := v_count + 1;
  end loop;
  return v_count;
end;
$$;
revoke all on function public.finalize_expired_auctions() from public, anon, authenticated;
grant execute on function public.finalize_expired_auctions() to service_role;

-- Operator accounts are provisioned manually by the database owner. Never let users self-assign admin access.
create table public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
-- No client-facing policies: only trusted server/service-role operations can inspect this table.

-- Row-level security
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.auctions enable row level security;
alter table public.auction_images enable row level security;
alter table public.bids enable row level security;
alter table public.watchlists enable row level security;
alter table public.orders enable row level security;
alter table public.payments enable row level security;
alter table public.seller_accounts enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;

create policy "Profiles are readable by authenticated users" on public.profiles for select to authenticated using (true);
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Categories are public" on public.categories for select using (is_active = true);
create policy "Active auctions are public" on public.auctions for select using (status = 'active' or seller_id = auth.uid());
create policy "Users create own auctions" on public.auctions for insert to authenticated with check (seller_id = auth.uid() and status in ('draft','pending_review'));
create policy "Users update own pending auctions" on public.auctions for update to authenticated using (seller_id = auth.uid() and status in ('draft','pending_review')) with check (seller_id = auth.uid() and status in ('draft','pending_review'));
create policy "Images for visible auctions are public" on public.auction_images for select using (exists(select 1 from public.auctions a where a.id = auction_id and (a.status = 'active' or a.seller_id = auth.uid())));
create policy "Seller adds images to own pending auction" on public.auction_images for insert to authenticated with check (exists(select 1 from public.auctions a where a.id = auction_id and a.seller_id = auth.uid() and a.status in ('draft','pending_review')));
create policy "Bid history for active or ended auctions" on public.bids for select using (exists(select 1 from public.auctions a where a.id = auction_id and a.status in ('active','ended')));
create policy "Users manage own watchlist" on public.watchlists for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "Buyer and seller view own orders" on public.orders for select to authenticated using (buyer_id = auth.uid() or seller_id = auth.uid());
create policy "Users view own payments" on public.payments for select to authenticated using (exists(select 1 from public.orders o where o.id = order_id and (o.buyer_id = auth.uid() or o.seller_id = auth.uid())));
create policy "Seller views own payout account" on public.seller_accounts for select to authenticated using (user_id = auth.uid());
create policy "Reviews are public" on public.reviews for select using (true);
create policy "Order parties create reviews" on public.reviews for insert to authenticated with check (reviewer_id = auth.uid() and exists(select 1 from public.orders o where o.id = order_id and o.status = 'completed' and (o.buyer_id = auth.uid() or o.seller_id = auth.uid()) and (o.buyer_id = reviewee_id or o.seller_id = reviewee_id)));
create policy "Users submit reports" on public.reports for insert to authenticated with check (reporter_id = auth.uid());
create policy "Users view own reports" on public.reports for select to authenticated using (reporter_id = auth.uid());

insert into public.categories (name,slug,sort_order) values
('車・バイク','cars-motorcycles',1),('家電・カメラ','electronics-camera',2),('ファッション','fashion',3),('時計・アクセサリー','watches-accessories',4),('ホビー','hobby',5),('家具・インテリア','home-interior',6),('工具・DIY','tools-diy',7),('スポーツ・アウトドア','sports-outdoor',8),('本・音楽・ゲーム','books-music-games',9),('その他','other',10)
on conflict (slug) do nothing;

-- Create a public image bucket. Restrict upload policies to authenticated users;
-- production should add per-user folder checks and file-type/size validation.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('auction-images','auction-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
create policy "Public read auction images" on storage.objects for select using (bucket_id = 'auction-images');
create policy "Authenticated upload auction images" on storage.objects for insert to authenticated with check (bucket_id = 'auction-images');
