"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

type Auction = {
  id: string; title: string; description?: string; category_id?: string;
  start_price: number; current_price: number; ends_at: string; status: string;
  auction_images?: { public_url: string }[]; categories?: { name: string } | null;
};

const demo: Auction[] = [
  { id: "demo-watch", title: "スイス製 機械式腕時計", description: "クラシックなデザインの機械式腕時計。", start_price: 38000, current_price: 42800, ends_at: "", status: "active", categories: { name: "時計・アクセサリー" } },
  { id: "demo-camera", title: "ミラーレス一眼カメラ", description: "撮影を楽しみたい方におすすめ。", start_price: 60000, current_price: 68500, ends_at: "", status: "active", categories: { name: "家電・カメラ" } },
  { id: "demo-bag", title: "本革レザーバッグ", description: "上質な本革を使用したバッグ。", start_price: 10000, current_price: 12500, ends_at: "", status: "active", categories: { name: "ファッション" } },
  { id: "demo-audio", title: "ヴィンテージレコードプレーヤー", description: "レトロな雰囲気のオーディオ機器。", start_price: 18000, current_price: 19800, ends_at: "", status: "active", categories: { name: "ホビー" } },
];
const categories = ["すべて", "車・バイク", "家電・カメラ", "ファッション", "時計・アクセサリー", "ホビー", "家具・インテリア", "工具・DIY", "その他"];
const yen = (n: number) => new Intl.NumberFormat("ja-JP", { style: "currency", currency: "JPY", maximumFractionDigits: 0 }).format(n);

export default function AuctionMarketplace({ initialAuctions, connected }: { initialAuctions: Auction[]; connected: boolean }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("すべて");
  const [message, setMessage] = useState("");
  const [showSell, setShowSell] = useState(false);
  const [localPrices, setLocalPrices] = useState<Record<string, number>>({});
  const items = initialAuctions.length ? initialAuctions : demo;
  const filtered = useMemo(() => items.filter((item) => {
    const matchesText = `${item.title} ${item.description ?? ""}`.toLowerCase().includes(query.toLowerCase());
    const cat = item.categories?.name ?? "その他";
    return matchesText && (category === "すべて" || cat === category);
  }), [items, query, category]);

  async function bid(item: Auction) {
    if (item.id.startsWith("demo-")) {
      setMessage("これは画面確認用のサンプル商品です。実際の入札には会員登録とデータベース接続が必要です。");
      return;
    }
    const current = localPrices[item.id] ?? item.current_price;
    const response = await fetch("/api/bids", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ auctionId: item.id, amount: current + 1000 }) });
    const result = await response.json();
    if (!response.ok) { setMessage(result.error ?? "入札できませんでした。"); return; }
    setLocalPrices((old) => ({ ...old, [item.id]: result.currentPrice }));
    setMessage("入札を受け付けました。");
  }

  return <main className="site-shell">
    <header className="topbar">
      <Link href="/" className="brand"><span className="brand-name">NOBLE AUCTION</span><span className="brand-sub">PREMIUM ONLINE MARKETPLACE</span></Link>
      <nav><a href="#auctions">商品を探す</a><a href="#about">ご利用ガイド</a><Link href="/login">ログイン</Link><button className="button button-gold button-small" onClick={() => setShowSell(!showSell)}>出品する ＋</button></nav>
    </header>

    <section className="hero">
      <div className="hero-copy"><span className="eyebrow">A BETTER WAY TO DISCOVER VALUE</span><h1>価値ある一品に、<br/><em>新しい出会いを。</em></h1><p>欲しかったものを見つける。大切な品物を次の人へ。<br/>上質で安心できるオークション体験を。</p><div className="hero-actions"><a className="button button-gold" href="#auctions">オークションを見る</a><button className="button button-outline" onClick={() => setShowSell(true)}>出品をはじめる</button></div></div>
      <div className="hero-art"><div className="hero-orbit orbit-one"/><div className="hero-orbit orbit-two"/><div className="hero-emblem">N<span>✦</span></div><div className="hero-caption">CURATED FINDS. OPEN POSSIBILITIES.</div></div>
    </section>

    {!connected && <div className="preview-note"><strong>プレビュー表示中</strong><span>現在はサンプル商品を表示しています。Supabaseを設定すると実際の商品データに切り替わります。</span></div>}
    {message && <div className="notice" role="status"><span>{message}</span><button onClick={() => setMessage("")} aria-label="閉じる">×</button></div>}

    {showSell && <section className="sell-panel"><div><span className="eyebrow">SELL ON NOBLE</span><h2>出品をはじめる</h2><p>出品機能を利用するには、会員登録とログインが必要です。</p></div><div className="sell-actions"><Link className="button button-gold" href="/login">会員登録・ログインへ</Link><button className="button button-outline" onClick={() => setShowSell(false)}>閉じる</button></div></section>}

    <section id="auctions" className="listing-section">
      <div className="section-heading"><div><span className="eyebrow">DISCOVER THE COLLECTION</span><h2>注目のオークション</h2></div><span className="result-count">{filtered.length} ITEMS</span></div>
      <div className="search-row"><label className="search-box"><span>⌕</span><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="商品名・キーワードで検索"/></label><div className="category-select"><select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="カテゴリー">{categories.map((c) => <option key={c}>{c}</option>)}</select></div></div>
      <div className="category-chips">{categories.map((c) => <button key={c} className={category === c ? "chip active" : "chip"} onClick={() => setCategory(c)}>{c}</button>)}</div>
      {filtered.length ? <div className="auction-grid">{filtered.map((item, index) => {
        const price = localPrices[item.id] ?? item.current_price;
        const image = item.auction_images?.[0]?.public_url;
        return <article className="auction-card" key={item.id}><div className={`product-visual visual-${index % 4}`} style={image ? { backgroundImage: `url(${image})` } : undefined}><span className="visual-label">{item.categories?.name ?? "FEATURED"}</span><span className="visual-mark">N.</span></div><div className="card-content"><div className="card-category">{item.categories?.name ?? "その他"}</div><h3>{item.title}</h3><div className="price-label">現在価格</div><div className="price">{yen(price)}</div><div className="card-bottom"><span>{item.ends_at ? `終了 ${new Date(item.ends_at).toLocaleString("ja-JP", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" })}` : "終了日時は商品ページで確認"}</span><button className="bid-button" onClick={() => bid(item)}>入札する ↗</button></div></div></article>;
      })}</div> : <div className="empty-state">条件に一致する商品はありません。</div>}
    </section>

    <section id="about" className="trust-strip"><div><span className="trust-icon">◇</span><strong>安心への取り組み</strong><span>本人確認・通報・取引記録</span></div><div><span className="trust-icon">⌁</span><strong>透明なオークション</strong><span>入札履歴と終了時刻を管理</span></div><div><span className="trust-icon">✧</span><strong>明確な手数料</strong><span>落札時の運営手数料 5％（予定）</span></div></section>
    <footer className="footer"><div><span className="brand-name">NOBLE AUCTION</span><p>価値ある一品に、新しい出会いを。</p></div><div className="footer-links"><a href="#about">ご利用ガイド</a><a href="#about">利用規約（公開前に整備）</a><a href="#about">プライバシーポリシー（公開前に整備）</a><a href="mailto:support@example.com">お問い合わせ（仮）</a></div><small>© {new Date().getFullYear()} NOBLE AUCTION. Prototype.</small></footer>
  </main>;
}
