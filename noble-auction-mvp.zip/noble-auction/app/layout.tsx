import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NOBLE AUCTION | Premium Online Marketplace",
  description: "価値ある一品に、新しい出会いを。NOBLE AUCTIONは総合オンラインオークションです。",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ja"><body>{children}</body></html>;
}
