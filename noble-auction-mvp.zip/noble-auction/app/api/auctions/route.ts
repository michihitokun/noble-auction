import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "出品するにはログインしてください。" }, { status: 401 });
    const body = await request.json();
    const title = typeof body.title === "string" ? body.title.trim() : "";
    const description = typeof body.description === "string" ? body.description.trim() : "";
    const startPrice = Number(body.startPrice);
    const categoryId = typeof body.categoryId === "string" ? body.categoryId : null;
    const endsAt = new Date(body.endsAt);
    if (title.length < 3 || title.length > 100 || !Number.isSafeInteger(startPrice) || startPrice < 1 || Number.isNaN(endsAt.getTime()) || endsAt.getTime() < Date.now() + 60 * 60 * 1000) {
      return NextResponse.json({ error: "商品名・開始価格・終了日時を確認してください。" }, { status: 400 });
    }
    const { data, error } = await supabase.from("auctions").insert({ seller_id: user.id, title, description, start_price: startPrice, current_price: startPrice, category_id: categoryId, ends_at: endsAt.toISOString(), status: "pending_review", platform_fee_rate: 0.05 }).select("id").single();
    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    return NextResponse.json({ ok: true, auctionId: data.id, message: "出品申請を受け付けました。運営者の確認後に公開されます。" });
  } catch {
    return NextResponse.json({ error: "サーバーエラーが発生しました。" }, { status: 500 });
  }
}
