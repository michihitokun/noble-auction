import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "入札するにはログインしてください。" }, { status: 401 });
    const body = await request.json();
    if (typeof body.auctionId !== "string" || !body.auctionId || !Number.isSafeInteger(body.amount) || body.amount <= 0) {
      return NextResponse.json({ error: "入札内容が正しくありません。" }, { status: 400 });
    }
    const { data, error } = await supabase.rpc("place_bid", { p_auction_id: body.auctionId, p_amount: body.amount });
    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    return NextResponse.json({ ok: true, currentPrice: data?.current_price, endsAt: data?.ends_at });
  } catch {
    return NextResponse.json({ error: "サーバーエラーが発生しました。" }, { status: 500 });
  }
}
