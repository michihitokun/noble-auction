"use client";
import { useState, type FormEvent } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function sendLink(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: `${window.location.origin}/auth/callback` } });
      if (error) throw error;
      setMessage("ログイン用リンクをメールで送信しました。メールをご確認ください。");
    } catch (err) { setMessage(err instanceof Error ? err.message : "送信できませんでした。Supabaseの設定を確認してください。"); }
    finally { setBusy(false); }
  }
  return <main className="auth-shell"><Link href="/" className="brand"><span className="brand-name">NOBLE AUCTION</span><span className="brand-sub">PREMIUM ONLINE MARKETPLACE</span></Link><section className="auth-card"><span className="eyebrow">MEMBER ACCESS</span><h1>ログイン・新規登録</h1><p>メールアドレスに届くリンクから、安全にログインできます。</p><form onSubmit={sendLink}><label htmlFor="email">メールアドレス</label><input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"/><button className="button button-gold" disabled={busy}>{busy ? "送信中..." : "ログインリンクを送信"}</button></form>{message && <p className="form-message" role="status">{message}</p>}<Link className="back-link" href="/">← トップページへ戻る</Link></section><p className="auth-foot">登録・利用の前に利用規約とプライバシーポリシーをご確認ください。公開版では正式文書へのリンクに差し替えます。</p></main>;
}
