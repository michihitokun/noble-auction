import AuctionMarketplace from "@/components/auction-marketplace";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  let auctions: any[] = [];
  let connected = false;
  try {
    const supabase = await createClient();
    const { data, error } = await supabase
      .from("auctions")
      .select("id,title,description,category_id,start_price,current_price,ends_at,status,auction_images(public_url),categories(name)")
      .eq("status", "active")
      .order("created_at", { ascending: false })
      .limit(24);
    if (!error) { auctions = data ?? []; connected = true; }
  } catch {
    // The site remains viewable in preview mode before Supabase is configured.
  }
  return <AuctionMarketplace initialAuctions={auctions} connected={connected} />;
}
