# NOBLE AUCTION — MVP starter

Japanese general-purpose online auction marketplace starter built with Next.js, TypeScript, and Supabase.

## iPad-only development

See [README_IPAD.md](./README_IPAD.md) for the browser-only setup using GitHub Codespaces. No local computer or local Node.js installation is required.

## Included

- Premium black / champagne-gold responsive marketplace homepage
- Product search and category filtering
- Preview cards while the database is not configured
- Email sign-in / registration screen
- Supabase browser and server clients
- Authenticated bid and listing API starter routes
- PostgreSQL schema for profiles, categories, auctions, images, bids, watchlists, orders, payments, seller accounts, reviews, and reports
- Database-side bid serialization and five-minute anti-sniping extension
- 5% platform fee snapshot on auctions and orders
- Row-level security policies

## Not production-ready

This is a development starter, not a live marketplace. Do not accept real money or invite the public to transact until all launch requirements are complete, including:

1. Supabase project setup and migration review.
2. Authentication callback and account lifecycle tests.
3. Image upload UI, storage policies, file validation, and moderation.
4. Member dashboards, order detail, shipping, messaging, reviews, reporting, and admin moderation.
5. Admin-only listing approval and suspension workflows.
6. Trusted scheduled auction finalization.
7. Approved marketplace payment provider and tested seller payout, refunds, chargebacks, identity verification, and fee accounting.
8. Security review, abuse prevention, rate limits, audit logs, backups, and monitoring.
9. Legally reviewed terms, privacy policy, prohibited-items policy, fee schedule, cancellation/refund/dispute rules, and operator disclosures.
10. Confirmation of Japanese secondhand-goods / internet-auction notification requirements with the competent police authority.

## Fee model

The default platform fee is 5% and is snapshotted per auction. The database calculation is an accounting illustration; actual payment processing fees, tax, refunds, chargebacks, shipping, and payout timing must be finalized before production.

## Provisional bid rules

- A seller cannot bid on their own listing.
- Auction row is locked during bid placement to serialize concurrent bids.
- Minimum increment: JPY 500 below 10,000; JPY 1,000 below 100,000; JPY 5,000 at or above 100,000.
- A bid in the last five minutes extends the end time to five minutes after the accepted bid.

These are provisional business rules and should be confirmed before launch.

## Secrets

Never expose `SUPABASE_SERVICE_ROLE_KEY` in browser code. It is not required by the current public pages and should only be used in trusted server jobs/admin routes.
