# NOBLE AUCTION — iPadだけで開発する手順

このプロジェクトは、iPad本体に開発ソフトを入れず、SafariとGitHub Codespaces（クラウド開発環境）を使って進められます。

## 先に用意するもの

- Safariが使えるiPad
- GitHub個人アカウント
- インターネット接続

## 1. GitHubにプロジェクトを置く

1. Safariで https://github.com/new を開き、GitHubにログインします。
2. Repository name に `noble-auction` と入力します。
3. Public / Private は、公開前のソースを守るため **Private** を選びます。
4. `Create repository` を押します。
5. 作成したリポジトリの `Add file` → `Upload files` を選び、受け取った `noble-auction-mvp.zip` をアップロードして `Commit changes` を押します。

## 2. Codespacesを起動する

1. リポジトリ画面で `Code` → `Codespaces` → `Create codespace on main` を選びます。
2. ブラウザ版Visual Studio Codeが開くまで待ちます。
3. 下部の `Terminal` → `New Terminal` を開きます。
4. 次のコマンドを1行ずつ実行します。

```bash
unzip noble-auction-mvp.zip
cp -a noble-auction/. .
rm -rf noble-auction noble-auction-mvp.zip
npm install
npm run dev
```

5. ポート3000の案内が表示されたら `Open in Browser` を押して、試作サイトを確認します。

## 3. Supabaseを接続する

1. https://supabase.com/ でアカウントを作り、新しいプロジェクトを作成します。
2. Supabaseの `SQL Editor` を開き、`supabase/migrations/0001_initial_schema.sql` の内容を貼り付けて実行します。
3. Supabaseの `Project Settings` → `API` から Project URL と anon/public key を確認します。
4. Codespacesのプロジェクト直下に `.env.local` を作成し、次の内容を設定します。

```env
NEXT_PUBLIC_SUPABASE_URL=SupabaseのProject URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=Supabaseのanon/public key
```

5. 開発サーバーを再起動します。

## 重要な注意

- `SUPABASE_SERVICE_ROLE_KEY` はブラウザに公開しないでください。
- Codespacesの利用には個人アカウントの月間無料枠がありますが、上限を超えると課金対象になり得ます。GitHubのBillingで利用量と予算上限を確認してください。
- このプロジェクトは開発用スターターです。現時点では、実際の出品・入札・決済・売上精算を一般利用者向けに提供できる完成品ではありません。
- 決済会社の審査、本人確認、古物営業法等の確認、利用規約・プライバシーポリシー、セキュリティ監査が完了するまで、実際のお金を受け取らず、一般公開の取引を開始しないでください。
